-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 30. 09 2016 kl. 11:59:27
-- Serverversion: 10.1.10-MariaDB
-- PHP-version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `profiler`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `Navn` varchar(25) NOT NULL,
  `Brugernavn` varchar(25) NOT NULL,
  `Password` varchar(225) NOT NULL,
  `Email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Data dump for tabellen `users`
--

INSERT INTO `users` (`id`, `Navn`, `Brugernavn`, `Password`, `Email`) VALUES
(23, 'Julie', 'Julie', '$2y$10$wEq4iY2fvBrDMc9RPnSsWOhPSxXlNFBU3AZCaVixOLUNSafbxj516', 'julie@julie.dk'),
(24, 'Julie', 'JulieVoravong', '$2y$10$UDVVebaR/Gzb1I3j0AnO7OmxxuMveq6ywbkJu4c9uc85c.lV2reXm', 'julie.voravong@hotmail.com'),
(25, 'zeb', 'zeb', '$2y$10$w4KyIsw.D.zzjnxxAVSTmOK1JuAkgO8gySP.y4R9klk4uVwFLR/06', 'zeb@zeb.dk');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Brugernavn` (`Brugernavn`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
